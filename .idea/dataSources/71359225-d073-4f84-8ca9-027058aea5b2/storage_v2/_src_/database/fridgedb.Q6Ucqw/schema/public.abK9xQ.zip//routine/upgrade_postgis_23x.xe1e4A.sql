CREATE FUNCTION upgrade_postgis_23x()
  RETURNS void
SECURITY DEFINER
SET search_path = public, pg_temp
LANGUAGE plpgsql
AS $$
DECLARE ver TEXT;
    BEGIN
            SELECT version INTO ver FROM pg_available_extension_versions WHERE name = 'postgis' AND version LIKE '2.3%';
            EXECUTE 'ALTER EXTENSION postgis UPDATE TO ' || quote_literal(ver);
    END;
$$;

