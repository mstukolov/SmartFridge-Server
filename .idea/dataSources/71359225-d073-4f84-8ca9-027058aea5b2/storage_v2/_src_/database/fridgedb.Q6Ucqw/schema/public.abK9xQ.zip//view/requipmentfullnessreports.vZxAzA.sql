CREATE VIEW requipmentfullnessreports AS
  SELECT requipmenttrans.retailequipmentid AS equipmentid,
    count(requipmenttrans.id) AS transqty,
    avg(round(((100)::double precision * abs(requipmenttrans.fullness)))) AS average,
    date_part('year'::text, requipmenttrans.createdat) AS year,
    date_part('month'::text, requipmenttrans.createdat) AS month,
    date_part('day'::text, requipmenttrans.createdat) AS day,
    date_part('hour'::text, requipmenttrans.createdat) AS hour
   FROM requipmenttrans
  GROUP BY requipmenttrans.retailequipmentid, (date_part('year'::text, requipmenttrans.createdat)), (date_part('month'::text, requipmenttrans.createdat)), (date_part('day'::text, requipmenttrans.createdat)), (date_part('hour'::text, requipmenttrans.createdat))
  ORDER BY (date_part('year'::text, requipmenttrans.createdat)), (date_part('month'::text, requipmenttrans.createdat)) DESC, (date_part('day'::text, requipmenttrans.createdat)) DESC, (date_part('hour'::text, requipmenttrans.createdat)) DESC;

