CREATE FUNCTION xpath(text, xml)
  RETURNS xml[]
IMMUTABLE
STRICT
PARALLEL SAFE
COST 1
LANGUAGE SQL
AS $$
select pg_catalog.xpath($1, $2, '{}'::pg_catalog.text[])
$$;

