CREATE VIEW requipmentdetailviews AS
  SELECT eqiup.id AS requipid,
    eqiup.serialnumber AS requipserialnumber,
    eqiup.maxvalue AS requipmaxvalue,
    trans.fullness AS requipfullness,
    trans.sensorvalue,
    trans.createdat,
    store.id AS storeid,
    store.name AS storename,
    chain.id AS rchainid,
    chain.name AS rchainname,
    location.address,
    location.lng,
    location.lat
   FROM ((((retailequipments eqiup
     JOIN retailstores store ON ((eqiup.retailstore_id = store.id)))
     JOIN locationequipment location ON ((eqiup.locationequipmentid = location.id)))
     JOIN retailchains chain ON ((store.retailchain_id = chain.id)))
     LEFT JOIN requipmentlasttrans trans ON ((eqiup.id = trans.retailequipmentid)));

