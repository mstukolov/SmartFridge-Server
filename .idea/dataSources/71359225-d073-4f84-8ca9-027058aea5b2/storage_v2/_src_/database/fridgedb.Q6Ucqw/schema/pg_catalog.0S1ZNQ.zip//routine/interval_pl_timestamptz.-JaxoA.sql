CREATE FUNCTION interval_pl_timestamptz(interval, timestamp with time zone)
  RETURNS timestamp with time zone
STABLE
STRICT
PARALLEL SAFE
COST 1
LANGUAGE SQL
AS $$
select $2 + $1
$$;

