CREATE VIEW retailequipmentdetails AS
  SELECT eq.id,
    eq.serialnumber,
    eq.filling,
    eq.lastvalue,
    eq.maxvalue,
    st.name AS store,
    ch.name AS chain,
    loc.address,
    loc.lat,
    loc.lng
   FROM (((retailequipments eq
     JOIN retailstores st ON ((eq.retailstoreid = st.id)))
     JOIN retailchains ch ON ((st.retailchainid = ch.id)))
     JOIN locationequipment loc ON ((eq.locationequipmentid = loc.id)));

