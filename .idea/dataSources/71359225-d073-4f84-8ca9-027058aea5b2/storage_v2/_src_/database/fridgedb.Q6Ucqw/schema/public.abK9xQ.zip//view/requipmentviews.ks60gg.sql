CREATE VIEW requipmentviews AS
  SELECT eqiup.id AS requipid,
    eqiup.serialnumber AS requipserialnumber,
    round((trans.fullness * (100)::double precision)) AS requipfilling,
    eqiup.maxvalue AS requipmaxvalue,
    trans.sensorvalue AS requiplastvalue,
    store.id AS storeid,
    store.name AS storename,
    chain.id AS rchainid,
    chain.name AS rchainname,
    trans.sensorvalue,
    trans.createdat
   FROM (((retailequipments eqiup
     JOIN retailstores store ON ((eqiup.retailstore_id = store.id)))
     JOIN retailchains chain ON ((store.retailchain_id = chain.id)))
     LEFT JOIN requipmentlasttrans trans ON ((eqiup.id = trans.retailequipmentid)));

