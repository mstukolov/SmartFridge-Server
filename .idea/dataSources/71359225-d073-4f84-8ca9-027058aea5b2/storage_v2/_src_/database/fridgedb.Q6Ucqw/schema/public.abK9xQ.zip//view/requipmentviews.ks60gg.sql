CREATE VIEW requipmentviews AS
  SELECT eqiup.id AS requipid,
    eqiup.serialnumber AS requipserialnumber,
    eqiup.filling AS requipfilling,
    eqiup.maxvalue AS requipmaxvalue,
    eqiup.lastvalue AS requiplastvalue,
    store.id AS storeid,
    store.name AS storename,
    chain.id AS rchainid,
    chain.name AS rchainname
   FROM ((retailequipments eqiup
     JOIN retailstores store ON ((eqiup.retailstore_id = store.id)))
     JOIN retailchains chain ON ((store.retailchain_id = chain.id)));

