CREATE VIEW requipmentviews AS
  SELECT eqiup.id AS requipid,
    eqiup.serialnumber AS requipserialnumber,
    (('-100'::integer)::double precision * trans.fullness) AS requipfullness,
    (((trans.sensorvalue)::double precision - micro.emptyweight) / micro.factor) AS sensorvalue,
    trans.createdat,
    store.id AS storeid,
    store.name AS storename,
    chain.id AS rchainid,
    chain.name AS rchainname
   FROM (((((retailequipments eqiup
     JOIN retailstores store ON ((eqiup.retailstore_id = store.id)))
     JOIN locationequipment location ON ((eqiup.locationequipmentid = location.id)))
     JOIN retailchains chain ON ((store.retailchain_id = chain.id)))
     JOIN microcontrollers micro ON ((eqiup.id = micro.requipmentid)))
     LEFT JOIN requipmentlasttrans trans ON ((eqiup.id = trans.retailequipmentid)));

