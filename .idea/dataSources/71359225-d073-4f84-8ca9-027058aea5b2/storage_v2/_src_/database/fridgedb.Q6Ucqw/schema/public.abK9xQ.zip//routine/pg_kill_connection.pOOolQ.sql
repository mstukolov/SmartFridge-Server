CREATE FUNCTION pg_kill_connection(integer)
  RETURNS boolean
SECURITY DEFINER
LANGUAGE SQL
AS $$
select pg_terminate_backend($1);
$$;

