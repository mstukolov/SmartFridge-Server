CREATE FUNCTION compose_session_replication_role(role text)
  RETURNS text
SECURITY DEFINER
LANGUAGE plpgsql
AS $$
DECLARE
                curr_val text := 'unset';
        BEGIN
                EXECUTE 'SET session_replication_role = ' || quote_literal(role);
                EXECUTE 'SHOW session_replication_role' INTO curr_val;
                RETURN curr_val;
        END
$$;

