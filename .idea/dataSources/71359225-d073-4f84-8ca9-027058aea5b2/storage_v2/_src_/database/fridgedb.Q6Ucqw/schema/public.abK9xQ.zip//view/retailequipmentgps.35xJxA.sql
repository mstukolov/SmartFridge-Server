CREATE VIEW retailequipmentgps AS
  SELECT eq.id,
    eq.serialnumber,
    loc.address,
    loc.lat,
    loc.lng
   FROM (((retailequipments eq
     JOIN retailstores st ON ((eq.retailstore_id = st.id)))
     JOIN retailchains ch ON ((st.retailchain_id = ch.id)))
     JOIN locationequipment loc ON ((eq.locationequipmentid = loc.id)));

